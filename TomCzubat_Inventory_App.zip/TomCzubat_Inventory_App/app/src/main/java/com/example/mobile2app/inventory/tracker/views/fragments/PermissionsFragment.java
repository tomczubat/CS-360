package com.example.mobile2app.inventory.tracker.views.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import androidx.fragment.app.DialogFragment;

import com.example.mobile2app.R;
import com.example.mobile2app.databinding.FragmentPermissionsBinding;
import com.example.mobile2app.inventory.tracker.interfaces.OnDialogConfirm;

public class PermissionsFragment extends DialogFragment {
    FragmentPermissionsBinding binding;
    OnDialogConfirm onDialogConfirm;

    public PermissionsFragment() {
        // Required empty public constructor
    }

    public static PermissionsFragment newInstance() {
        PermissionsFragment fragment = new PermissionsFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentPermissionsBinding.inflate(inflater, container, false);
        View view = binding.getRoot();
        Button btnAllow = view.findViewById(R.id.btnAllow);
        ImageView btnCancel = view.findViewById(R.id.btnCancel);
        btnAllow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OnDialogConfirm onDialogConfirm = (OnDialogConfirm)requireActivity();
                onDialogConfirm.onDialogConfirm();
                dismiss();
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });
        return view;
    }
}
