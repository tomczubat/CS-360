package com.example.mobile2app.inventory.tracker.interfaces;

public interface OnDialogConfirm{
    void onDialogConfirm();
}
