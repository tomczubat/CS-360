package com.example.mobile2app.inventory.tracker.views;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mobile2app.R;
import com.example.mobile2app.databinding.ActivityInventoryItemBinding;
import com.example.mobile2app.inventory.tracker.MainActivity;
import com.google.android.material.snackbar.Snackbar;

public class InventoryItemActivity extends AppCompatActivity {
    private ActivityInventoryItemBinding binding;
    private View view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInventoryItemBinding.inflate(getLayoutInflater());
        view = binding.getRoot();
        setContentView(view);
        getSupportActionBar().setTitle(Html.fromHtml("<font color=\"#FFFFFFF\">" + getString(R.string.inventory_item) + "</font>"));

        binding.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSnack("Adding item feature will be implemented soon!");
            }
        });
    }

    private void showSnack(String msg) {
        Snackbar.make(view, msg, Snackbar.LENGTH_LONG).setAction("OK", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(InventoryItemActivity.this, MainActivity.class));
            }
        }).show();
    }

}
